'use strict';
/**
 * Belmont Tables volunteer app: a zero-dependency Node server.
 * Needs Node 22.13 or newer (uses the built-in node:sqlite module).
 */
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');

/* ---------- config (.env is optional) ---------- */
const ROOT = __dirname;
try {
  for (const line of fs.readFileSync(path.join(ROOT, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch (_) { /* no .env file */ }
process.env.TZ = process.env.TZ || 'America/Chicago'; // Nashville

const { DatabaseSync } = require('node:sqlite');
const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const WEEKS = 8;
const list = (v) => (v || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
const COORDINATORS = list(process.env.COORDINATOR_EMAILS);
const ALLOWED_DOMAINS = list(process.env.ALLOWED_EMAIL_DOMAINS);
fs.mkdirSync(DATA_DIR, { recursive: true });

let SECRET = process.env.SESSION_SECRET;
if (!SECRET) {
  const f = path.join(DATA_DIR, 'secret.key');
  if (!fs.existsSync(f)) fs.writeFileSync(f, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
  SECRET = fs.readFileSync(f, 'utf8').trim();
}

/* ---------- database ---------- */
const db = new DatabaseSync(path.join(DATA_DIR, 'belmont.db'));
db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT, family TEXT NOT NULL, team_no INTEGER NOT NULL DEFAULT 0,
  size INTEGER NOT NULL DEFAULT 0, dietary TEXT NOT NULL DEFAULT '', dropoff TEXT NOT NULL DEFAULT '',
  dropoffs TEXT NOT NULL DEFAULT '{}', notes TEXT NOT NULL DEFAULT '', color INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, pass TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student', team_id INTEGER REFERENCES teams(id) ON DELETE SET NULL,
  created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, dow INTEGER NOT NULL,
  start TEXT NOT NULL, "end" TEXT NOT NULL, skip TEXT NOT NULL DEFAULT '[]');
CREATE TABLE IF NOT EXISTS signups (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  date TEXT NOT NULL, created_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, session_id, date));
`);

function seed() {
  if (db.prepare('SELECT COUNT(*) n FROM sessions').get().n) return;
  const s = db.prepare('INSERT INTO sessions (title,dow,start,"end") VALUES (?,?,?,?)');
  s.run('Sodexo volunteering', 1, '15:00', '16:30');
  s.run('Cul2vate volunteering', 4, '15:00', '16:30');
  if (db.prepare('SELECT COUNT(*) n FROM teams').get().n) return;
  const t = db.prepare('INSERT INTO teams (family,team_no,size,dietary,dropoff,dropoffs,notes,color) VALUES (?,?,?,?,?,?,?,?)');
  t.run('Humphrey', 1, 5, '', 'To be confirmed (last year: Fidelity parking lot)', '{}', '', 0);
  t.run('Bishop', 3, 5, 'No allergies. Prefers healthy: vegetables, proteins, fruits.', "Cory Bishop's Office, JCM361", '{}', '', 2);
  t.run('Biggs', 4, 0, '', '', JSON.stringify({ 1: '4:00-4:30 PM, Gabhart Student Life Center (Belmont Central) with Lara', 4: '2:00-3:30 PM (before 3:30), Facilities Management Building with Isaac' }), '', 3);
  t.run('Waterman', 5, 7, 'None reported', '', JSON.stringify({ 1: 'Inman 202B', 4: 'In front of FCOM at 4:30 PM' }), '', 4);
}
seed();

/* ---------- helpers ---------- */
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const bad = (m) => new HttpError(400, m);
const scryptHash = (pw, salt = crypto.randomBytes(16).toString('hex')) => `${salt}:${crypto.scryptSync(pw, salt, 64).toString('hex')}`;
function checkPw(pw, stored) {
  const [salt, hash] = stored.split(':');
  const a = Buffer.from(hash, 'hex'), b = crypto.scryptSync(pw, salt, 64);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const b64 = (b) => Buffer.from(b).toString('base64url');
function makeToken(uid) {
  const p = `${uid}.${Date.now() + 30 * 864e5}`;
  return `${p}.${crypto.createHmac('sha256', SECRET).update(p).digest('base64url')}`;
}
function readToken(tok) {
  const [uid, exp, sig] = (tok || '').split('.');
  if (!uid || !exp || !sig) return null;
  const want = crypto.createHmac('sha256', SECRET).update(`${uid}.${exp}`).digest('base64url');
  if (sig.length !== want.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(want))) return null;
  return Number(exp) > Date.now() ? Number(uid) : null;
}
function cookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function setSession(req, res, uid) {
  const secure = req.headers['x-forwarded-proto'] === 'https' || process.env.COOKIE_SECURE === '1';
  const val = uid ? makeToken(uid) : '';
  res.setHeader('Set-Cookie', `bt_session=${val}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${uid ? 30 * 86400 : 0}${secure ? '; Secure' : ''}`);
}
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
function validDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const [y, m, d] = s.split('-').map(Number), dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d ? dt : null;
}
const validTime = (s) => typeof s === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
const str = (v, max, name, req) => {
  const s = typeof v === 'string' ? v.trim() : '';
  if (req && !s) throw bad(`${name} is required.`);
  if (s.length > max) throw bad(`${name} is too long (max ${max} characters).`);
  return s;
};
const int = (v, min, max, name) => {
  const n = Number.parseInt(v, 10);
  if (v === '' || v == null) return 0;
  if (!Number.isFinite(n) || n < min || n > max) throw bad(`${name} must be a number from ${min} to ${max}.`);
  return n;
};
const parseJSON = (s, fb) => { try { return JSON.parse(s); } catch (_) { return fb; } };
const teamOut = (t) => ({ id: t.id, family: t.family, teamNo: t.team_no, size: t.size, dietary: t.dietary, dropoff: t.dropoff, dropoffs: parseJSON(t.dropoffs, {}), notes: t.notes, color: t.color });
const sessionOut = (s) => ({ id: s.id, title: s.title, dow: s.dow, start: s.start, end: s.end, skip: parseJSON(s.skip, []) });

/* is this date a real, open occurrence of the session? */
function checkOccurrence(session, date) {
  const dt = validDate(date);
  if (!dt) throw bad('That date is not valid.');
  if (dt.getDay() !== session.dow) throw bad('That day does not match this volunteer day.');
  if (parseJSON(session.skip, []).includes(date)) throw bad('That day has been cancelled.');
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const last = new Date(today); last.setDate(last.getDate() + WEEKS * 7);
  if (dt < today || dt >= last) throw bad('That day is outside the sign-up window.');
  const [h, m] = session.end.split(':').map(Number);
  const endAt = new Date(dt); endAt.setHours(h, m, 0, 0);
  if (endAt <= new Date()) throw bad('That shift has already ended.');
}

/* ---------- rate limit for sign-in ---------- */
const attempts = new Map();
function limited(key) {
  const now = Date.now(), a = (attempts.get(key) || []).filter((t) => now - t < 15 * 60e3);
  attempts.set(key, a);
  return a.length >= 10;
}
const noteAttempt = (key) => attempts.set(key, [...(attempts.get(key) || []), Date.now()]);

/* ---------- api ---------- */
const routes = [];
function route(method, pattern, opts, handler) {
  routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), opts, handler });
}
const userById = (id) => db.prepare('SELECT * FROM users WHERE id=?').get(id);
function promote(user) {
  if (COORDINATORS.includes(user.email) && user.role !== 'coordinator') {
    db.prepare("UPDATE users SET role='coordinator' WHERE id=?").run(user.id);
    user.role = 'coordinator';
  }
  return user;
}

route('POST', '/api/register', { public: true }, ({ req, res, body }) => {
  const name = str(body.name, 60, 'Name', true);
  const email = str(body.email, 120, 'Email', true).toLowerCase();
  const pw = typeof body.password === 'string' ? body.password : '';
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw bad('Enter a valid email address.');
  if (ALLOWED_DOMAINS.length && !ALLOWED_DOMAINS.some((d) => email.endsWith('@' + d))) throw bad(`Use your school email (${ALLOWED_DOMAINS.map((d) => '@' + d).join(' or ')}).`);
  if (pw.length < 8 || pw.length > 100) throw bad('Choose a password with 8 to 100 characters.');
  if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email)) throw new HttpError(409, 'An account with that email already exists. Sign in instead.');
  const r = db.prepare('INSERT INTO users (name,email,pass,role,created_at) VALUES (?,?,?,?,?)')
    .run(name, email, scryptHash(pw), COORDINATORS.includes(email) ? 'coordinator' : 'student', Date.now());
  setSession(req, res, Number(r.lastInsertRowid));
  return { ok: true };
});

route('POST', '/api/login', { public: true }, ({ req, res, body }) => {
  const email = str(body.email, 120, 'Email', true).toLowerCase();
  const key = `${req.socket.remoteAddress}|${email}`;
  if (limited(key)) throw new HttpError(429, 'Too many attempts. Wait a few minutes and try again.');
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!u || typeof body.password !== 'string' || !checkPw(body.password, u.pass)) {
    noteAttempt(key);
    throw new HttpError(401, 'Email or password is incorrect.');
  }
  promote(u);
  setSession(req, res, u.id);
  return { ok: true };
});

route('POST', '/api/logout', { public: true }, ({ req, res }) => { setSession(req, res, null); return { ok: true }; });

route('POST', '/api/password', {}, ({ user, body }) => {
  const cur = typeof body.current === 'string' ? body.current : '';
  const next = typeof body.next === 'string' ? body.next : '';
  if (!checkPw(cur, user.pass)) throw new HttpError(400, 'Your current password is not right.');
  if (next.length < 8 || next.length > 100) throw bad('Choose a new password with 8 to 100 characters.');
  db.prepare('UPDATE users SET pass=? WHERE id=?').run(scryptHash(next), user.id);
  return { ok: true };
});

route('GET', '/api/state', {}, ({ user }) => {
  const coord = user.role === 'coordinator';
  const out = {
    me: { id: user.id, name: user.name, email: user.email, role: user.role, teamId: user.team_id },
    weeks: WEEKS,
    sessions: db.prepare('SELECT * FROM sessions ORDER BY dow, start').all().map(sessionOut),
  };
  const cols = 'SELECT s.session_id sessionId, s.date, u.id userId, u.name, u.team_id teamId FROM signups s JOIN users u ON u.id=s.user_id';
  if (coord) {
    out.teams = db.prepare('SELECT * FROM teams ORDER BY team_no, family').all().map(teamOut);
    out.signups = db.prepare(cols + ' ORDER BY s.date').all();
    out.students = db.prepare('SELECT id,name,email,role,team_id teamId FROM users ORDER BY name COLLATE NOCASE').all();
  } else if (user.team_id) {
    out.teams = db.prepare('SELECT * FROM teams WHERE id=?').all(user.team_id).map(teamOut);
    out.signups = db.prepare(cols + ' WHERE u.team_id=? ORDER BY s.date').all(user.team_id);
  } else { out.teams = []; out.signups = []; }
  return out;
});

route('POST', '/api/signups', {}, ({ user, body }) => {
  if (!user.team_id && user.role !== 'coordinator') throw new HttpError(403, 'You have not been assigned to a team yet.');
  if (!user.team_id) throw new HttpError(403, 'Assign yourself to a team first (Coordinator tab).');
  const s = db.prepare('SELECT * FROM sessions WHERE id=?').get(Number(body.sessionId));
  if (!s) throw new HttpError(404, 'That volunteer day no longer exists.');
  const dates = Array.isArray(body.dates) ? body.dates.slice(0, 60) : [body.date];
  dates.forEach((d) => checkOccurrence(s, d));
  const ins = db.prepare('INSERT OR IGNORE INTO signups (user_id,session_id,date,created_at) VALUES (?,?,?,?)');
  dates.forEach((d) => ins.run(user.id, s.id, d, Date.now()));
  return { ok: true, added: dates.length };
});

route('POST', '/api/signups/remove', {}, ({ user, body }) => {
  db.prepare('DELETE FROM signups WHERE user_id=? AND session_id=? AND date=?').run(user.id, Number(body.sessionId), String(body.date));
  return { ok: true };
});

/* coordinator only */
const C = { coord: true };
function teamFields(b) {
  const d = {};
  for (const k of [1, 4]) { const v = str((b.dropoffs || {})[k], 200, 'Drop-off'); if (v) d[k] = v; }
  return [str(b.family, 40, 'Family name', true), int(b.teamNo, 0, 99, 'Team number'), int(b.size, 0, 40, 'Family size'),
    str(b.dietary, 200, 'Dietary needs'), str(b.dropoff, 200, 'Drop-off'), JSON.stringify(d), str(b.notes, 400, 'Notes')];
}
route('POST', '/api/teams', C, ({ body }) => {
  const n = db.prepare('SELECT COUNT(*) n FROM teams').get().n;
  const r = db.prepare('INSERT INTO teams (family,team_no,size,dietary,dropoff,dropoffs,notes,color) VALUES (?,?,?,?,?,?,?,?)').run(...teamFields(body), n % 6);
  return { ok: true, id: Number(r.lastInsertRowid) };
});
route('PUT', '/api/teams/:id', C, ({ params, body }) => {
  const r = db.prepare('UPDATE teams SET family=?,team_no=?,size=?,dietary=?,dropoff=?,dropoffs=?,notes=? WHERE id=?').run(...teamFields(body), Number(params.id));
  if (!r.changes) throw new HttpError(404, 'Family not found.');
  return { ok: true };
});
route('DELETE', '/api/teams/:id', C, ({ params }) => { db.prepare('DELETE FROM teams WHERE id=?').run(Number(params.id)); return { ok: true }; });

route('POST', '/api/sessions', C, ({ body }) => {
  const title = str(body.title, 60, 'Name', true), dow = int(body.dow, 0, 6, 'Weekday');
  if (!validTime(body.start) || !validTime(body.end) || body.end <= body.start) throw bad('Set a start time that is before the end time.');
  db.prepare('INSERT INTO sessions (title,dow,start,"end") VALUES (?,?,?,?)').run(title, dow, body.start, body.end);
  return { ok: true };
});
route('DELETE', '/api/sessions/:id', C, ({ params }) => { db.prepare('DELETE FROM sessions WHERE id=?').run(Number(params.id)); return { ok: true }; });
route('POST', '/api/sessions/:id/skip', C, ({ params, body }) => {
  const s = db.prepare('SELECT * FROM sessions WHERE id=?').get(Number(params.id));
  if (!s) throw new HttpError(404, 'Volunteer day not found.');
  if (!validDate(body.date)) throw bad('That date is not valid.');
  let skip = parseJSON(s.skip, []).filter((d) => d !== body.date);
  if (body.skip) skip.push(body.date);
  db.prepare('UPDATE sessions SET skip=? WHERE id=?').run(JSON.stringify(skip.sort()), s.id);
  if (body.skip) db.prepare('DELETE FROM signups WHERE session_id=? AND date=?').run(s.id, body.date);
  return { ok: true };
});
route('PUT', '/api/students/:id', C, ({ params, body }) => {
  const tid = body.teamId == null || body.teamId === '' ? null : Number(body.teamId);
  if (tid !== null && !db.prepare('SELECT 1 FROM teams WHERE id=?').get(tid)) throw bad('That family does not exist.');
  db.prepare('UPDATE users SET team_id=? WHERE id=?').run(tid, Number(params.id));
  return { ok: true };
});
route('POST', '/api/students/:id/reset-password', C, ({ params }) => {
  const u = userById(Number(params.id));
  if (!u) throw new HttpError(404, 'Student not found.');
  const temp = crypto.randomBytes(6).toString('base64url');
  db.prepare('UPDATE users SET pass=? WHERE id=?').run(scryptHash(temp), u.id);
  return { ok: true, password: temp };
});
route('GET', '/api/export.csv', C, ({ res }) => {
  const rows = db.prepare(`SELECT s.date, se.title, COALESCE(t.family,'') family, COALESCE(t.team_no,'') team_no, u.name, u.email
    FROM signups s JOIN users u ON u.id=s.user_id JOIN sessions se ON se.id=s.session_id LEFT JOIN teams t ON t.id=u.team_id ORDER BY s.date, se.title, t.team_no, u.name`).all();
  const esc = (v) => { v = String(v); if (/^[=+\-@]/.test(v)) v = "'" + v; return /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v; };
  const csv = ['Date,Volunteer day,Family,Team,Student,Email', ...rows.map((r) => [r.date, r.title, r.family, r.team_no, r.name, r.email].map(esc).join(','))].join('\r\n');
  res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="belmont-tables-signups.csv"' });
  res.end(csv);
  return undefined;
});

/* ---------- server ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.json': 'application/json' };
const SEC = {
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
  'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin',
};
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 100e3) { reject(new HttpError(413, 'Request too large.')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(v && typeof v === 'object' ? v : {}); }
      catch (_) { reject(bad('Request was not valid JSON.')); }
    });
    req.on('error', reject);
  });
}
function sendJSON(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...SEC });
  res.end(JSON.stringify(obj));
}
function serveStatic(req, res, pathname) {
  const rel = pathname === '/' ? '/index.html' : pathname;
  const file = path.normalize(path.join(ROOT, 'public', rel));
  if (!file.startsWith(path.join(ROOT, 'public') + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const ext = path.extname(file);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' || file.endsWith('sw.js') ? 'no-cache' : 'public, max-age=3600', ...SEC });
    res.end(req.method === 'HEAD' ? undefined : buf);
  });
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (!url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Method not allowed.');
      return serveStatic(req, res, decodeURIComponent(url.pathname));
    }
    const r = routes.map((x) => x.method === req.method && x.re.exec(url.pathname) ? { x, m: x.re.exec(url.pathname) } : null).find(Boolean);
    if (!r) throw new HttpError(404, 'Not found.');
    let body = {};
    if (req.method !== 'GET') {
      if (!(req.headers['content-type'] || '').startsWith('application/json')) throw new HttpError(415, 'Send JSON.');
      body = await readBody(req);
    }
    let user = null;
    if (!r.x.opts.public) {
      const uid = readToken(cookies(req).bt_session);
      user = uid && userById(uid);
      if (!user) throw new HttpError(401, 'Please sign in.');
      promote(user);
      if (r.x.opts.coord && user.role !== 'coordinator') throw new HttpError(403, 'Coordinators only.');
    }
    const out = r.x.handler({ req, res, body, user, params: r.m.groups || {} });
    if (out !== undefined) sendJSON(res, 200, out);
  } catch (e) {
    if (res.headersSent) return res.end();
    if (e instanceof HttpError) return sendJSON(res, e.status, { error: e.message });
    console.error(e);
    sendJSON(res, 500, { error: 'Something went wrong on the server.' });
  }
}).listen(PORT, () => {
  console.log(`Belmont Tables is running at http://localhost:${PORT}`);
  if (!COORDINATORS.length) console.log('Tip: set COORDINATOR_EMAILS in .env (or run "npm run make-coordinator -- you@school.edu") so someone can manage families.');
});

module.exports = { db };
